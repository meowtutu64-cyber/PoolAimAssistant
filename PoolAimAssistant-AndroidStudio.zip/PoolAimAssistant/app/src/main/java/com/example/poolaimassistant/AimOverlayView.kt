package com.example.poolaimassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * Manual overlay: tap cue ball, object ball, then intended pocket/target direction.
 * This MVP does not read the game screen or control the game.
 */
class AimOverlayView(context: Context) : View(context) {
    private val points = mutableListOf<Pair<Float, Float>>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2.2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dp(14f)
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    }
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC101820.toInt()
        style = Paint.Style.FILL
    }
    private var downX = 0f
    private var downY = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (visibility != VISIBLE) return

        canvas.drawRoundRect(dp(12f), dp(36f), width - dp(12f), dp(106f), dp(12f), dp(12f), panel)
        val instruction = when (points.size) {
            0 -> "1/3  Ketuk posisi tengah bola putih"
            1 -> "2/3  Ketuk posisi tengah bola sasaran"
            2 -> "3/3  Ketuk arah tujuan / lubang"
            else -> "Selesai • Ketuk RESET di kanan atas untuk ulang"
        }
        canvas.drawText(instruction, dp(24f), dp(64f), text)
        text.textSize = dp(11f)
        canvas.drawText("Mode manual • tidak membaca atau mengendalikan game", dp(24f), dp(87f), text)
        text.textSize = dp(14f)

        if (points.isNotEmpty()) {
            drawPoint(canvas, points[0], Color.WHITE, "CUE")
        }
        if (points.size >= 2) {
            val cue = points[0]
            val obj = points[1]
            drawPoint(canvas, obj, Color.YELLOW, "TARGET")
            drawLine(canvas, cue, obj, Color.WHITE, true)
            val r = dp(15f)
            val dx = obj.first - cue.first
            val dy = obj.second - cue.second
            val len = hypot(dx, dy).coerceAtLeast(1f)
            val ux = dx / len
            val uy = dy / len
            val contact = Pair(obj.first - ux * r, obj.second - uy * r)
            dot.color = Color.RED
            canvas.drawCircle(contact.first, contact.second, dp(5f), dot)
        }
        if (points.size >= 3) {
            val obj = points[1]
            val pocket = points[2]
            drawPoint(canvas, pocket, Color.GREEN, "TUJUAN")
            drawLine(canvas, obj, pocket, Color.YELLOW, true)
            val dx = obj.first - points[0].first
            val dy = obj.second - points[0].second
            val angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
            val info = "Arah cue: ${"%.1f".format(angle)}°"
            canvas.drawText(info, dp(24f), height - dp(30f), text)
        }

        // Reset hit area
        canvas.drawRoundRect(width - dp(104f), dp(44f), width - dp(22f), dp(92f),
            dp(9f), dp(9f), panel)
        canvas.drawText("RESET", width - dp(88f), dp(74f), text)
    }

    private fun drawPoint(c: Canvas, p: Pair<Float, Float>, color: Int, label: String) {
        dot.color = color
        c.drawCircle(p.first, p.second, dp(7f), dot)
        text.color = color
        c.drawText(label, p.first + dp(10f), p.second - dp(10f), text)
        text.color = Color.WHITE
    }

    private fun drawLine(c: Canvas, a: Pair<Float, Float>, b: Pair<Float, Float>, color: Int, dashed: Boolean) {
        line.color = color
        line.pathEffect = if (dashed) android.graphics.DashPathEffect(floatArrayOf(dp(9f), dp(7f)), 0f) else null
        c.drawLine(a.first, a.second, b.first, b.second, line)
        line.pathEffect = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                val reset = event.x > width - dp(112f) && event.y < dp(112f)
                if (reset) points.clear()
                else if (event.y > dp(112f)) {
                    if (points.size >= 3) points.clear()
                    points.add(Pair(event.x, event.y))
                }
                invalidate()
                return true
            }
        }
        return true
    }

    fun resetIfClosed(closed: Boolean) {
        if (closed) {
            points.clear()
            invalidate()
        }
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
