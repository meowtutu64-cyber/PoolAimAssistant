package com.example.poolaimassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.TextView
import android.graphics.Color

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var aimView: AimOverlayView? = null
    private var aimParams: WindowManager.LayoutParams? = null
    private var isOpen = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
        showAimLayer()
    }

    private fun overlayType(): Int =
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "AIM"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(18, 125, 90))
            setOnClickListener { toggleAim() }
        }
        val p = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18); y = dp(180)
        }
        bubble = b
        wm.addView(b, p)
    }

    private fun showAimLayer() {
        val v = AimOverlayView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        aimView = v
        aimParams = p
        wm.addView(v, p)
    }

    private fun toggleAim() {
        isOpen = !isOpen
        val p = aimParams ?: return
        p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!isOpen) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        aimView?.visibility = if (isOpen) View.VISIBLE else View.GONE
        aimView?.resetIfClosed(!isOpen)
        aimView?.let { wm.updateViewLayout(it, p) }
        bubble?.text = if (isOpen) "TUTUP" else "AIM"
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        aimView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        aimView = null
        super.onDestroy()
    }
}
