plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.poolaimassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.poolaimassistant"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0"
    }
}
