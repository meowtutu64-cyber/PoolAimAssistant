# Pool Aim Assistant (MVP)

Proyek Android Studio untuk overlay analisis bidikan manual.

## Fitur MVP
- Floating bubble `AIM` yang dapat membuka/menutup lapisan overlay.
- Tandai tiga titik secara manual: bola putih, bola sasaran, dan arah tujuan/lubang.
- Garis prediksi visual sederhana dan sudut arah cue.
- Tidak membaca layar game secara otomatis, tidak mengirim input ke game, dan tidak mengubah aplikasi 8 Ball Pool.

## Build APK
1. Buka folder `PoolAimAssistant` di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
5. Pasang APK di perangkat Android.
6. Buka aplikasi dan izinkan **Display over other apps / Tampil di atas aplikasi lain**.
7. Tekan **Mulai floating assistant**, lalu buka 8 Ball Pool.

## Catatan
Ini masih prototipe awal. Penandaan posisi dilakukan manual dan overlay dapat menutupi sentuhan pada layar ketika mode AIM aktif. Untuk menutup overlay, tekan tombol `TUTUP`. Untuk menghentikan layanan sepenuhnya, buka kembali aplikasi dan tekan `Hentikan assistant`.

Belum ada deteksi bola otomatis, pengenalan screenshot, maupun perhitungan fisika tumbukan/pantulan yang akurat.
